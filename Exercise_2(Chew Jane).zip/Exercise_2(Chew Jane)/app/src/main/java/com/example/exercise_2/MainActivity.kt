package com.example.exercise_2

import android.graphics.ImageFormat
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var weight : EditText
    private lateinit var height : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        weight = findViewById(R.id.editTextWeight)
        height = findViewById(R.id.editTextHeight)

        buttonCalculate.setOnClickListener{showResult()}
        buttonReset.setOnClickListener{reset()}
    }

    private fun showResult(){


        val BMI = weight.text.toString().toDouble() / (((height.text.toString().toDouble())/100)*((height.text.toString().toDouble())/100))


        if(BMI < 18.5){
            imageViewProfile.setImageResource(R.drawable.under)
        }
        else if(BMI < 25){
            imageViewProfile.setImageResource(R.drawable.normal)
        }
        else{
            imageViewProfile.setImageResource(R.drawable.over)
        }

        textViewBMI.setText(String.format("BMI : %.2f",BMI))

    }

    private fun reset(){
        editTextHeight.setText("")
        editTextWeight.setText("")
        textViewBMI.setText("BMI : ")
        imageViewProfile.setImageResource((R.drawable.empty))
        editTextWeight.requestFocus()
    }
}
