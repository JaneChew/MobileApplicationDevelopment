package com.example.exercise_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {

    private lateinit var carPrice : EditText
    private lateinit var downPayment : EditText
    private lateinit var loanPeriod : EditText
    private lateinit var interestRate : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        carPrice = findViewById(R.id.editTextCarPrice)
        downPayment = findViewById(R.id.editTextDownPayment)
        loanPeriod = findViewById(R.id.editTextLoanPeriod)
        interestRate = findViewById(R.id.editTextInterestRate)

        buttonCalculate.setOnClickListener{ showResult()}
        buttonReset.setOnClickListener{contentReset()}

    }

    private fun showResult(){

        val loan = carPrice.text.toString().toDouble() - downPayment.text.toString().toDouble()
        val interest = loan * (interestRate.text.toString().toDouble()/100) * loanPeriod.text.toString().toDouble()
        val monthlyRepayment = (loan + interest) / loanPeriod.text.toString().toDouble() / 12

        textViewLoan.setText(String.format("Loan : RM%.2f",loan))
        textViewInterest.setText(String.format("Interest : RM%.2f",interest))
        textViewMonthlyRepayment.setText(String.format("Monthly Repayment: RM%.2f",monthlyRepayment))


    }

    private fun contentReset(){
        editTextCarPrice.setText("")
        editTextDownPayment.setText("")
        editTextInterestRate.setText("")
        editTextLoanPeriod.setText("")
        textViewLoan.setText("Loan : ")
        textViewInterest.setText("Interest : ")
        textViewMonthlyRepayment.setText("Monthly Repayment : ")
        editTextCarPrice.requestFocus()
    }

}
